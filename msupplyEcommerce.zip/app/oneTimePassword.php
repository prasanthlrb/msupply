<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class oneTimePassword extends Model
{
    //
}
