<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class upload extends Model
{
    //
}
