<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_attribute extends Model
{
    //
}
